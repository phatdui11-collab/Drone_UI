#include "sensor/sensor_common.h"
#include "sensor/bmp280_sensor.h"
#include "main.h"
#include <math.h>

IMU_RAW_DATA_t MPU6500_RAW_DATA;
IMU_Data_t MPU6500_DATA;

MAG_RAW_DATA_t MAG_RAW_DATA_INST;
MAG_DATA_t MAG_DATA_INST;

MagCal_Simple_t MagCal = {
    .S = 1.0f,
    .state = MAG_CAL_DONE,
    .samples_target = 5000,
    .offset = {188.0f, -348.0f, -455.5f},
    .scale = {1.02f, 0.97f, 1.0f}
};

Complimentary_Filter_t Complimentary_Filter = {
    .alpha = {0.99f, 0.99f, 0.96f},
    .Offset_Deg = {0.0f, 0.0f, 58.23f},
    .Offset_Rad = {0.0f, 0.0f, 58.23f * (float32_t)DEG_TO_RAD}
};

PID_ALTIDUE_t PID_RATE_ROLL = {
    .alpha_lpf = 0.88f, .feed_forward = 0.05f, .i_limit = 75, .max_output = 400,
    .kp = 0.700993f, .ki = 1.265000f, .kd = 0.112501f, .d_limit = 22.5f, .i_deadband = 1.0f,
};

PID_ALTIDUE_t PID_RATE_PITCH = {
    .alpha_lpf = 0.88f, .feed_forward = 0.05f, .i_limit = 75, .max_output = 400,
    .kp = 0.700993f, .ki = 1.265000f, .kd = 0.112501f, .d_limit = 22.5f, .i_deadband = 1.0f,
};

PID_ALTIDUE_t PID_RATE_YAW = {
    .alpha_lpf = 0.88f, .feed_forward = 0.05f, .i_limit = 75, .max_output = 400,
    .kp = 1.456010f, .ki = 1.401011f, .kd = 0.138702f, .d_limit = 22.5f, .i_deadband = 1.0f,
};

PID_ALTIDUE_t PID_ROLL = {
    .alpha_lpf = 0.88f, .feed_forward = 0, .i_limit = 65, .max_output = 150,
    .kp = 1.7f, .ki = 0.007f, .kd = 1.8f, .d_limit = 22.5f,
};

PID_ALTIDUE_t PID_PITCH = {
    .alpha_lpf = 0.88f, .feed_forward = 0, .i_limit = 65, .max_output = 150,
    .kp = 1.7f, .ki = 0.007f, .kd = 1.8f, .d_limit = 22.5f,
};

PID_ALTIDUE_t PID_YAW = {
    .alpha_lpf = 0.88f, .feed_forward = 0, .i_limit = 60, .max_output = 120,
    .kp = 1.5f, .ki = 0.001f, .kd = 0.0f, .d_limit = 22.5f,
};

MPC_Status_t MPC_Status = HOVER;
ARM_Status_t ARM_Status = NOT_ARM;

int16_t raw_acc[3];
int16_t raw_gyro[3];
float32_t acc_phys[3];
float32_t gyro_phys[3];
uint8_t enable_motor = 0;

float32_t Throttle = 1000.0f;
float32_t Moment[3];
float32_t angle_desired[3] = {0, 0, 0};
float32_t angle_rate_desired[3] = {0, 0, 0};

float32_t PWM_MOTOR[4];
uint32_t PWM_TIMER[4];

float vbat = 11.1f;

float32_t gyro_final[3] = {0.0f, 0.0f, 0.0f};
float32_t acc_filtered[3] = {0.0f, 0.0f, 0.0f};
const float32_t alpha_acc_soft = 0.02f;
const float32_t alpha_gyro = 0.05f;
float32_t mag_filtered[3] = {0.0f, 0.0f, 0.0f};
uint8_t mag_lpf_inited = 0;

float32_t gyro_bias[3] = {0.0f, 0.0f, 0.0f};
float32_t accel_bias[3] = {0.0f, 0.0f, 0.0f};
uint8_t is_calibrated = 0;

volatile uint32_t RC_Raw_Roll = 0;
volatile uint32_t RC_Raw_Pitch = 0;
volatile uint32_t RC_Raw_Throttle = 0;
volatile uint32_t RC_Raw_Yaw = 0;
volatile uint32_t RC_Raw_SW_Arm = 0;
volatile uint32_t RC_Raw_SW_Mode = 0;
volatile uint32_t RC_Raw_SW_PosHold = 0;

float32_t Baro_Alt_m = 0.0f;
float32_t Baro_Pressure_Pa = 0.0f;
float32_t Ground_Pressure_Pa = 0.0f;
uint8_t Baro_GroundCalibrated = 0U;

void Baro_Calibrate(void)
{
    float p, t;
    float sum_p = 0.0f;
    uint32_t valid_samples = 0;
    
    if (!BMP280_IsReady()) {
        Baro_GroundCalibrated = 0U;
        return;
    }

    for (int i = 0; i < 50; i++) {
        if (BMP280_ReadCompensated(&p, &t)) {
            sum_p += p;
            valid_samples++;
        }
        HAL_Delay(10);
    }
    
    if (valid_samples > 0) {
        Ground_Pressure_Pa = sum_p / (float)valid_samples;
        Baro_GroundCalibrated = 1U;
        Baro_Alt_m = 0.0f;
    } else {
        Baro_GroundCalibrated = 0U;
    }
}

void BARO_PROCESS(void)
{
    float p, t;
    if (BMP280_ReadCompensated(&p, &t)) {
        if (Baro_Pressure_Pa == 0.0f) {
            Baro_Pressure_Pa = p;
        } else {
            Baro_Pressure_Pa = Baro_Pressure_Pa * 0.9f + p * 0.1f;
        }

        if (Baro_GroundCalibrated == 0U) {
            Ground_Pressure_Pa = Baro_Pressure_Pa;
            Baro_GroundCalibrated = 1U;
            Baro_Alt_m = 0.0f;
            return;
        }

        if (Ground_Pressure_Pa > 0.0f) {
            float alt = 44330.0f * (1.0f - powf(Baro_Pressure_Pa / Ground_Pressure_Pa, 0.1903f));
            if (Baro_Alt_m == 0.0f) {
                Baro_Alt_m = alt;
            } else {
                Baro_Alt_m = Baro_Alt_m * 0.9f + alt * 0.1f;
            }
        }
    }
}
